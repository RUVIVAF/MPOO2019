//
//  TrackTableViewController.swift
//  itunes_RVVF
//
//  Created by Macbook on 3/21/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class TrackTableViewController : UITableViewController{
    var tracks: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .green
        getTracks()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tracks.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        cell.textLabel!.text=tracks[indexPath.row]
        return cell
    }
     
    
    func getTracks(){
        let url =   URL(string: "https://itunes.apple.com/search?term=theKillers")
        let jsonDecoder = JSONDecoder()
        let Task = URLSession.shared.dataTask(with: url!){(data,response,error) in
            if let data = data, let resultado = try? jsonDecoder.decode(Results.self, from: data){
                for track in resultado.results{
                    print(track.trackName)
                   self.tracks.append(track.trackName)
                }
                    self.tableView.reloadData()
            }
        }
        Task.resume()
    }
}

