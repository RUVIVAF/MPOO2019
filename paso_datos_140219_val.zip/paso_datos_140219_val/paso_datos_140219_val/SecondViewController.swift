//
//  SecondViewController.swift
//  paso_datos_140219_val
//
//  Created by Macbook on 2/14/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var dato: String = ""
    
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var textoUsuario: UITextField!
    var dato2: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        // Do any additional setup after loading the view.
        print(dato)
        etiqueta.text = dato
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toFirstView"{
            let FirstView = segue.destination as? ViewController
            
        }
    
}

