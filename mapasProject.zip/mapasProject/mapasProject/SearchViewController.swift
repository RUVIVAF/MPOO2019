//
//  SearchViewController.swift
//  mapasProject
//
//  Created by Macbook on 5/2/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import MapKit

class SearchViewController: UIViewController {

    
    @IBOutlet weak var buscar: UISearchBar!
    @IBOutlet weak var mapa: MKMapView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buscar.delegate = self
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
        buscar.resi
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(buscar. 
    }
    
    
    
    
}
