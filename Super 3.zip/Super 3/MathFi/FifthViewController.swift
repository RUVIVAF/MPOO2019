//
//  FifthViewController.swift
//  MathFi
//
//  Created by Macbook on 3/22/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController {
    
    var dosVariable : Int?
    var hide1 : Bool = false
    
    @IBOutlet weak var boton2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        boton2.isHidden = hide1
    }
    @IBAction func goToNextView(_ sender: Any) {
        let view = self.storyboard?.instantiateViewController(withIdentifier: "SixthViewController") as? SixthViewController
        view?.unaVariable = 2
        view?.hide = true
        self.navigationController?.pushViewController(view!, animated: false)
//        self.present(view!, animated: true, completion: nil)
        
    }


}
