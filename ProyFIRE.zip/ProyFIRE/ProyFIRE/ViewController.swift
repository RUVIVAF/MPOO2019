//
//  ViewController.swift
//  ProyFIRE
//
//  Created by Macbook on 4/4/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit
import  Firebase

class ViewController: UIViewController {

    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func createUser(_ sender:UIButton) {
        guard let usuarioCorreo = correo.text,usuarioCorreo != "", let usuarioContraseña = contraseña.text, usuarioContraseña != "" else{
            return
        }
        
        Auth.auth().createUser(withEmail: usuarioCorreo, password: usuarioContraseña) { (user,error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            print("Se creo el usuario: " + user!.user.uid)
        }
    }
    


}

