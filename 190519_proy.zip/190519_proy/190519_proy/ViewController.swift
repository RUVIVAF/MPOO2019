//
//  ViewController.swift
//  190519_proy
//
//  Created by Macbook on 5/14/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    var defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let datos = defaults.object(forKey: "datos") as? String{
        caja.text = datos
    }
        
    }

    @IBAction func guardar(_ sender: Any) {
        if let datos = caja.text, datos != ""{
            defaults.set(datos, forKey: "datos")
            print("Datos guardados")
            performSegue(withIdentifier: "toSecondView", sender: self)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let datos = defaults.object(forKey: "datos") as? String{
        caja.text = datos
            print ("datos recuperados")
        }else{
            print("No hubo datos")
        }
    }
    
}

