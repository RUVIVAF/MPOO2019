//
//  ViewController.swift
//  Proy_RVVF_01
//
//  Created by Macbook on 2/28/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var confirmacion: UILabel!
    var _confirmacionVista2 : String = ""
    var band2 : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*if (secondView?.band == true) {
            band2 = "exito"
        }else{
            band2 = "fail"
        }*/
    }
}

