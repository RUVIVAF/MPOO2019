//
//  ViewController.swift
//  ClasesAndStructures_RVVF
//
//  Created by Macbook on 2/28/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var botoncito: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        //botoncito.isEnabled = false
    }
}

