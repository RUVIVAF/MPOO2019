//
//  ViewController.swift
//  SOLEJERRVVF
//
//  Created by Macbook on 2/19/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var deSegundaVista : String = ""
    
    @IBOutlet weak var etiqueta: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        etiqueta.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        etiqueta.isHidden = true
        etiqueta.text = deSegundaVista
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondView = segue.destination as? SecondViewController
        secondView?.datoDesdeVista1 = "Saludos de vista1"
        secondView?.viewController = self
    }

}

