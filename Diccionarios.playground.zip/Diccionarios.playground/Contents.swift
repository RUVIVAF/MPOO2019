import Foundation


let libro1: [String: String] = ["autor": "Gabriel García Márquez", "titulo": "Cien años de soledad", "clasificacion": "ISBN", "anio": "1970"]

struct Libro: Decodable {
    var autor: String?
    var titulo: String?
    var clasificacion: String?
    var anio: String?
}

let miLbro = Libro(autor: libro1["autor"], titulo: libro1["titulo"], clasificacion: libro1["clasificacion"], anio: libro1["anio"])

//var Libros = [Libro]() //arreglo de libros

let json = """
{
    "libros": [
        {
            "autor": "Jorge Ibarguengoitia",
            "titulo": "Dos crimenes",
            "clasificacion": "PQYHSWH21254",
            "anio": "1960"
        },
        {
            "autor": "Jorge Ibarguengoitia",
            "titulo": "Dos crimenes",
            "clasificacion": "PQYHSWH21254",
            "anio": "1960"
        },
        {
            "autor": "Rosario Castellanos",
            "titulo": "Dos crimenes",
            "clasificacion": "PQYHSWH287896",
            "anio": "1978"
        },
        {
            "autor": "Conan Doyle",
            "titulo": "Sherlock Holmes",
            "clasificacion": "PQYHSWH98y988",
            "anio": "1947"
        },
        {
            "autor": "Jose Agustin",
            "titulo": "La tumba",
            "clasificacion": "PQYHSWH9089",
            "anio": "1969"
        }
    ]
}
""".data(using: .utf8)


let decoder = JSONDecoder()

let parsingJSON = try decoder.decode([String: [Libro]].self, from: json!)

if let libros = parsingJSON["libros"] {
    for libro in libros {
        print(libro.titulo)
    }
}
