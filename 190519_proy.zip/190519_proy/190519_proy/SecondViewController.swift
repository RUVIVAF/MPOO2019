//
//  SecondViewController.swift
//  190519_proy
//
//  Created by Macbook on 5/14/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
var defaults = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func borrarDatos(_ sender: Any) {
        defaults.set("", forKey: "datos")
        
        
    }
}
