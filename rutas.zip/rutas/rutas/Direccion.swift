//
//  Direccion.swift
//  rutas
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import Foundation
import UIKit
import MapKit


class Direccion: NSObject, MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(title: String,subtitle: String, coordinate: CLLocationCoordinate2D){
        self.coordinate=coordinate
        self.title=title
        self.subtitle=subtitle
    }
}
