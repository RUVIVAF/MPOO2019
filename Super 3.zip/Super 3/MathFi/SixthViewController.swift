//
//  SixthViewController.swift
//  MathFi
//
//  Created by Macbook on 3/26/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class SixthViewController: UIViewController {
    var unaVariable : Int?
    var hide : Bool = false
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        button.isHidden = hide

    }

    @IBAction func goTeoria(_ sender: Any) {
        let view = self.storyboard?.instantiateViewController(withIdentifier: "FifthViewController") as? FifthViewController
        view?.dosVariable = 2
        view?.hide1 = true
        self.navigationController?.pushViewController(view!, animated: false)
    }
    

}
