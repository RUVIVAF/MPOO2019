//
//  materia.swift
//  MathFi
//
//  Created by Macbook on 4/23/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import Foundation

struct Materias {
    var nombre: String
}
struct cellData {
    var opened = Bool()
    var subjectNam = String()//En el video el nombre es tittle
    var sectionData = [String]() // Data que esta adentro de la celda
}

struct Materia1{
    var tema: String
    var info: String
}


