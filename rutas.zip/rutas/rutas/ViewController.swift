
import UIKit
import MapKit

class ViewController: UIViewController,MKMapViewDelegate {
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 24.019894, longitude: -104.660824)
        let destinoLocation = CLLocationCoordinate2D(latitude: 24.023059, longitude: -104.652279)
        
        let inicioPin = Direccion(title: "Direccion1", subtitle: "inicio", coordinate: inicioLocation)
        
        let destinoPin = Direccion(title: "Direccion2", subtitle: "destino", coordinate: destinoLocation)
        
        self .mapa.addAnnotation(inicioPin)
        self .mapa.addAnnotation(destinoPin)
    
        let inicioPlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: destinoLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: inicioPlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate{ (response, error) in
        
        guard let directionResponse = response else{
            if let error = error{
                print(error.localizedDescription)
            }
            return
        }
            
            let ruta = directionResponse.routes[0]
            self.mapa.addOverlay(ruta.polyline, level: .aboveRoads)
            let rect = ruta.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion(rect), animated: true)
    }
    
        self.mapa.delegate = self
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let linea = MKPolygonRenderer(overlay: overlay)
        linea.strokeColor = UIColor.red
        linea.lineWidth = 4.8
        return linea
    }
}


