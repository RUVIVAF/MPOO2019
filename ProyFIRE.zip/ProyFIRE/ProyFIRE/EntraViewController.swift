//
//  EntraViewController.swift
//  ProyFIRE
//
//  Created by Macbook on 4/4/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit
import Firebase

class EntraViewController: UIViewController {

    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var correo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func entrar(_ sender: Any) {
        guard let usuarioCorreo = correo.text,usuarioCorreo != "", let usuarioContraseña = contraseña.text, usuarioContraseña != "" else{
            return
        }
        
        Auth.auth().signIn(withEmail: usuarioCorreo, password: usuarioCorreo) { (user,error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            self.dismiss(animated: true, completion: nil)
            print("si es el usuario")
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
