import UIKit

class Dulce{
    var nombre : String
    var precio : Float
    var gramos : Int
    init ( nombre: String, precio: Float, gramos: Int){
        self.nombre = nombre
        self.precio = precio
        self.gramos = gramos
    }
}

class Pan : Dulce{
    var delDia : Bool
    override init(nombre: String, precio: Float, gramos: Int) {
        self.delDia = true
        super.init(nombre: nombre, precio: precio, gramos: gramos)
    }
     init(nombre: String, precio: Float, gramos: Int, delDia: Bool) {
        self.delDia = delDia
        super.init(nombre: nombre, precio: precio, gramos: gramos)
    }
}

class Caja{
    let dulces : [Dulce]
    init(dulces : [Dulce]){
        self.dulces = dulces
    }
    
    func getTotal() -> Float{
        var total : Float = 0.0
        for dulce in dulces{
            total += dulce.precio
        }
        return total
    }

}

let pulparindo = Dulce(nombre: "PULPARINDO", precio: 4.00, gramos: 5)
let paleta = Dulce(nombre: "PALETA", precio: 10.00, gramos: 6)
let dona = Pan(nombre: "DONA", precio: 30.76, gramos: 6)
let concha = Pan(nombre: "CONCHA", precio: 9.00, gramos: 6, delDia: true)

var arregloDulces=[pulparindo, paleta, dona,concha]
let caja = Caja(dulces: arregloDulces)

print(caja.getTotal())





