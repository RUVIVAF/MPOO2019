//
//  ViewController.swift
//  mapasProject
//
//  Created by Macbook on 5/2/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import MapKit //Utilza el mapa
import CoreLocation //Perdirle al usuario la información


//Manager --> a través de él accedemos a la info // debe delegar su comportamiento a la clase que lo va a contener

//K es una constante


class ViewController: UIViewController,  CLLocationManagerDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    var manager = CLLocationManager()
    var latitud : CLLocationDegrees!
    var longitud : CLLocationDegrees!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        manager.desiredAccuracy = kCLLocationAccuracyBest //Que tan buena presición se tiene
        manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            print(location)
            self.longitud = location.coordinate.longitude
            self.latitud = location.coordinate.latitude
        }
    }
    
    @IBAction func getCoords(_ sender: UIButton){
        
        print(longitud,latitud)
        
        let localizacion = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.01,longitudeDelta:0.01) //Que tan lejos o que tan cerca
        
        let region = MKCoordinateRegion(center: localizacion, span: span)
        mapa.setRegion(region, animated: true)
        mapa.showsUserLocation = true
        mapa.mapType = .hybrid
    }
    

}

