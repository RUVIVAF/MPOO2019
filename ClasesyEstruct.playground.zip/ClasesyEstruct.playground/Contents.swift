import UIKit

class Persona {
    var nombre : String
    var edad : Int
    var sexo: String
    
    func comer (){
        print("\(self.nombre) esta comiendo")
    }
    
    func dormir(){
        print("\(self.nombre) esta durmiedo")
    }
    
    func bailar(){
        print("\(self.nombre) esta bailando")
    }
    
    //Inicializador de la clase
    
    init (_nombre : String, _edad : Int, _sexo: String){
        self.nombre = _nombre
        self.edad = _edad
        self.sexo = _sexo
    }
}

let  juan = Persona(_nombre: "Juan", _edad: 19, _sexo: "Hombre")
var persona1 = Persona(_nombre: "Hjsjgwqgd", _edad: 56, _sexo: "Hombre")

print(juan.nombre)
juan.bailar()
print("Los datos de Victor son: ")
print(persona1.nombre)
print(persona1.edad)
print(persona1.sexo)
persona1.comer()

//juan = persona1 //Lo que estamos cambiando las variables //Por esa razón hay que ocupar let
persona1 = juan
print(persona1.nombre)

//LAS CLASES SIEMPRE SE PASAN POR REFERENCIA

print("ESTRUCTURAS")

struct alumno{
    var nombre : String
    var noCuenta : String
    var promedio : Int
    
    func estudiar(){
        print("\(nombre) ESTA ESTUDIANDO PARA PROBA")
    }
    
    func comer(){
        print("\(nombre) ESTA COMIENDO ")
    }
    
}

/*let carlos = alumno(nombre: "Carlos", noCuenta: "8763875", promedio: 7)
carlos.noCuenta
carlos.nombre
carlos.promedio*/

class Empleado : Persona{
    
    var puesto : String
    var horasDeTrabajo: Int
    
    init(_nombre: String, _edad: Int, _sexo: String, _puesto: String,_horasDeTrabajo: Int ) {
        self.puesto = _puesto
        self.horasDeTrabajo = _horasDeTrabajo
        super.init(_nombre: _nombre, _edad: _edad, _sexo: _sexo)
        
    }
    override func comer(){
        super.comer()
        print("Ahora es godin")
    }
}

let godin = Empleado(_nombre: "Carlos", _edad: 19, _sexo: "Hombre",_puesto: "CEO", _horasDeTrabajo: 78587)

godin.comer()
godin.nombre
