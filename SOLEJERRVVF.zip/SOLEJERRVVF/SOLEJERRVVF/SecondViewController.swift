//
//  SecondViewController.swift
//  SOLEJERRVVF
//
//  Created by Macbook on 2/19/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var viewController : ViewController!
    
    @IBOutlet weak var etiqueta2: UILabel!
    var datoDesdeVista1 : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta2.text=datoDesdeVista1
        // Do any additional setup after loading the view.
    }
    
    @IBAction func regresar(_ sender: UIButton){
       // etiqueta2.text=datoDesdeVista1
        viewController.deSegundaVista="Saludos desde vista 2"
        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
