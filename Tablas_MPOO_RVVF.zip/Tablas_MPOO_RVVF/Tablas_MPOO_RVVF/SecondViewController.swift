//
//  SecondViewController.swift
//  Tablas_MPOO_RVVF
//
//  Created by Macbook on 2/26/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var nombre: UILabel!
    var dato: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        nombre.text=dato
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cerrar(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
    
}
