//
//  SecondViewController.swift
//  Proy_RVVF_01
//
//  Created by Macbook on 2/28/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var apellido: UITextField!
    @IBOutlet weak var nombre: UITextField!
    
    var _nombre : String = "Valentina"
    var _apellido : String = "Ruiz"
    var band : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
   @IBAction func verificaDatos(_ sender : UIButton){
        if _nombre == nombre.text && _apellido == apellido.text{
            print("Datos correctos")
            band = true
            verifica(_band: band)
        }else{
            print("Datos incorrectos")
            band = false
        }
        //dismiss(animated: true, completion: nil)
    }

    
    func verifica(_band : Bool){
        if _band == true{
            performSegue(withIdentifier: "toThirdView"){//, sender: self){
                print("Todo bien")
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let thirdView = segue.destination as? ThirdViewController
        thirdView?.nombreUrs = nombre.text!
    }
}

