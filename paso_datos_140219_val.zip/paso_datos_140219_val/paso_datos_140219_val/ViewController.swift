//
//  ViewController.swift
//  paso_datos_140219_val
//
//  Created by Macbook on 2/14/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var texto2: UILabel!
    override internal func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toSecondView"{
            let secondView = segue.destination as? SecondViewController
            secondView?.dato = "HOLA MUNDO"
            
        }
    }

}

