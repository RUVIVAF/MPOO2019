//
//  SecondViewController.swift
//  PracticaVistas
//
//  Created by Macbook on 2/19/19.
//  Copyright © 2019 ClaseMPOO. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    //var deVistaDos: String = ""
    @IBOutlet weak var Caja: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare( for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "OneView"{
            let vistaDestino = segue.destination as! ViewController
            vistaDestino.deVistaDos = Caja.text!
            
            //vistaDestino.TextoMuestra = Caja.text!
        }
        
    }
    
    
    @IBAction func Regresar(_ sender: UIButton) {
            dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
        

    }
    
}
