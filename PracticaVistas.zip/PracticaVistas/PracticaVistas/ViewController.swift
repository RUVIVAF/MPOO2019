//
//  ViewController.swift
//  PracticaVistas
//
//  Created by Macbook on 2/19/19.
//  Copyright © 2019 ClaseMPOO. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var deVistaDos: String = ""
    
    @IBOutlet weak var TextoMuestra: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        TextoMuestra.text = deVistaDos
    }


}

