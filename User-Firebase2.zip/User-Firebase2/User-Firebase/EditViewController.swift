//
//  EditViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/29/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase

class EditViewController: UIViewController{
    @IBOutlet weak var nombreTF: UITextField!
    @IBOutlet weak var apellidoTF: UITextField!
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    var alumno: Alumno!
    var id: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nombreTF.text = alumno.nombre
        apellidoTF.text = alumno.apellido
        id = alumno.id
        
        ref = Firestore.firestore().collection("alumno").document(id)
        
    }
    
    @IBAction func editAlumno(_ sender: UIButton){
        
        let values: [String:Any] = ["nombre": nombreTF.text, "apellido":apellidoTF.text]
        
        ref.setData(values) { (error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("Datos actualizados")
            }
        }
        dismiss(animated: true, completion: nil)
    }
}
